"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Loader2, AlertTriangle, ArrowLeft } from "lucide-react"

const POSITION_CONFIGS = {
  "airmen-enlistee": {
    title: "Airmen Enlistee Application",
    description: "Entry-level position application",
    questions: [
      "Why do you want to join USAF24 as an Airmen Enlistee?",
      "What skills or qualities do you bring to our team?",
      "How many hours per week can you dedicate to USAF24 activities?",
      "Describe any relevant gaming or military simulation experience you have.",
      "What are your long-term goals within USAF24?",
    ],
  },
  nco: {
    title: "Non-Commissioned Officer Application",
    description: "Leadership position application",
    questions: [
      "Describe your leadership experience and style.",
      "How would you handle conflicts between team members?",
      "What strategies would you use to motivate and develop junior members?",
      "Describe a challenging situation you've overcome in a leadership role.",
      "What improvements would you suggest for USAF24's current operations?",
      "How do you plan to contribute to the growth and success of USAF24?",
    ],
  },
  "commissioned-officer": {
    title: "Commissioned Officer Application",
    description: "Senior leadership position application",
    questions: [
      "Outline your vision for USAF24's strategic direction.",
      "Describe your experience in high-level decision making.",
      "How would you handle budget allocation and resource management?",
      "What is your approach to organizational change and development?",
      "Describe your experience in inter-organizational relationships and partnerships.",
      "How would you ensure USAF24 maintains its competitive edge?",
      "What metrics would you use to measure organizational success?",
    ],
  },
  "field-officer": {
    title: "Field Officer Application",
    description: "Specialized field operations position",
    questions: [
      "Describe your tactical and operational experience.",
      "How do you approach mission planning and execution?",
      "What is your experience with field training and exercises?",
      "How do you handle high-pressure operational situations?",
      "Describe your knowledge of military tactics and procedures.",
      "How would you train and prepare team members for field operations?",
    ],
  },
}

export default function ApplicationPage() {
  const params = useParams()
  const router = useRouter()
  const position = params.position as string

  const [formData, setFormData] = useState({
    discordUsername: "",
    discordId: "",
    robloxUsername: "",
    hasAtcRole: "",
    customAnswers: [] as string[],
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [botStatus, setBotStatus] = useState<"checking" | "online" | "offline">("checking")
  const [showSystemDown, setShowSystemDown] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  const config = POSITION_CONFIGS[position as keyof typeof POSITION_CONFIGS]

  useEffect(() => {
    if (!config) {
      router.push("/")
      return
    }

    // Initialize custom answers array
    setFormData((prev) => ({
      ...prev,
      customAnswers: new Array(config.questions.length).fill(""),
    }))

    checkBotStatus()
    const interval = setInterval(checkBotStatus, 10000) // Check every 10 seconds during application
    return () => clearInterval(interval)
  }, [config, router])

  const checkBotStatus = async () => {
    try {
      const response = await fetch("/api/bot-status")
      const data = await response.json()
      const isOnline = data.online

      if (botStatus === "online" && !isOnline) {
        // Bot went offline during application
        setShowSystemDown(true)
      } else if (botStatus === "offline" && isOnline) {
        // Bot came back online
        setShowSystemDown(false)
      }

      setBotStatus(isOnline ? "online" : "offline")
    } catch (error) {
      setBotStatus("offline")
      if (botStatus === "online") {
        setShowSystemDown(true)
      }
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleAnswerChange = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      customAnswers: prev.customAnswers.map((answer, i) => (i === index ? value : answer)),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (botStatus !== "online") {
      setError("Cannot submit application while system is offline")
      return
    }

    // Validation
    if (
      !formData.discordUsername.trim() ||
      !formData.discordId.trim() ||
      !formData.robloxUsername.trim() ||
      !formData.hasAtcRole
    ) {
      setError("Please fill in all required fields")
      return
    }

    if (formData.customAnswers.some((answer) => !answer.trim())) {
      setError("Please answer all questions")
      return
    }

    setIsSubmitting(true)
    setError("")

    try {
      const response = await fetch("/api/submit-application", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          position: config.title,
          positionSlug: position,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess(true)
      } else {
        setError(data.error || "Failed to submit application")
      }
    } catch (error) {
      setError("Failed to submit application. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!config) {
    return null
  }

  if (botStatus === "checking") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="flex items-center justify-center p-8">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
              <p>Loading application...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="text-green-600 mb-4">
              <svg className="w-16 h-16 mx-auto" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-green-700 mb-2">Application Submitted!</h2>
            <p className="text-green-600 mb-6">
              Your application for {config.title} has been successfully submitted. You will receive a DM on Discord with
              updates about your application status.
            </p>
            <Button onClick={() => router.push("/")} className="w-full">
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      {showSystemDown && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md mx-4">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-yellow-700 mb-2">System Temporarily Down</h2>
              <p className="text-yellow-600 mb-4">
                Our system is temporarily offline. Please do not close this tab or you will lose your work. We'll
                automatically resume when the system is back online.
              </p>
              <div className="flex items-center justify-center">
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                <span className="text-sm">Waiting for system to come back online...</span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <Button variant="ghost" onClick={() => router.push("/")} className="mb-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Positions
          </Button>

          <Card>
            <CardHeader>
              <CardTitle>{config.title}</CardTitle>
              <CardDescription>{config.description}</CardDescription>
            </CardHeader>
          </Card>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="discordUsername">Discord Username *</Label>
                  <Input
                    id="discordUsername"
                    placeholder="e.g., username#1234"
                    value={formData.discordUsername}
                    onChange={(e) => handleInputChange("discordUsername", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="discordId">Discord ID *</Label>
                  <Input
                    id="discordId"
                    placeholder="e.g., 123456789012345678"
                    value={formData.discordId}
                    onChange={(e) => handleInputChange("discordId", e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="robloxUsername">Roblox Username *</Label>
                <Input
                  id="robloxUsername"
                  placeholder="Your Roblox username"
                  value={formData.robloxUsername}
                  onChange={(e) => handleInputChange("robloxUsername", e.target.value)}
                  required
                />
              </div>

              <div className="space-y-3">
                <Label>Do you have the ATC24 role in ATC24? *</Label>
                <RadioGroup
                  value={formData.hasAtcRole}
                  onValueChange={(value) => handleInputChange("hasAtcRole", value)}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="atc-yes" />
                    <Label htmlFor="atc-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="atc-no" />
                    <Label htmlFor="atc-no">No</Label>
                  </div>
                </RadioGroup>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Application Questions</CardTitle>
              <CardDescription>Please answer all questions thoroughly</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {config.questions.map((question, index) => (
                <div key={index} className="space-y-2">
                  <Label htmlFor={`question-${index}`}>
                    {index + 1}. {question} *
                  </Label>
                  <Textarea
                    id={`question-${index}`}
                    placeholder="Your answer..."
                    value={formData.customAnswers[index] || ""}
                    onChange={(e) => handleAnswerChange(index, e.target.value)}
                    className="min-h-[100px]"
                    required
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="flex gap-4">
            <Button type="button" variant="outline" onClick={() => router.push("/")} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1" disabled={isSubmitting || botStatus !== "online"}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Application"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
