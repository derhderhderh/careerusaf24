export async function POST(request: Request) {
  try {
    const body = await request.json()
    const botApiUrl = process.env.BOT_API_URL || "https://acc1d220a697.ngrok-free.app"

    const response = await fetch(`${botApiUrl}/api/check-role`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })

    const data = await response.json()

    if (!response.ok) {
      return Response.json(data, { status: response.status })
    }

    return Response.json(data)
  } catch (error) {
    console.error("Error checking role:", error)
    return Response.json({ error: "Failed to connect to bot service" }, { status: 503 })
  }
}
