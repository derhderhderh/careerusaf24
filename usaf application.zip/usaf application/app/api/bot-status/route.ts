export async function GET() {
  try {
    const botApiUrl = process.env.BOT_API_URL || "https://acc1d220a697.ngrok-free.app"
    const response = await fetch(`${botApiUrl}/api/bot-status`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      throw new Error("Bot API not responding")
    }

    const data = await response.json()
    return Response.json({ online: true, ...data })
  } catch (error) {
    return Response.json({ online: false, error: "Bot offline" })
  }
}
